import Cocoa

func execute(name: String, complationBlock: () -> ()) {
  print("Execute \(name)")
  complationBlock()
}

execute(name: "sub-task-1", complationBlock: {
  print("1. Hello world!")
})

execute(name: "sub-task-2", complationBlock: {
  let Int1 = 12
  print("1. \(Int1)")
  let Int2 = -100
  print("2.",Int2 )
  let Int3 = 0x80
  print("3.",Int3)
  let Int4 = Int16.min
  print ("4.",Int4)
  let Int5 = Int64.max
  print ("5.",Int5)
  let Int6 = Double(10235.34)
  print ("6.",Int6)
  print ("7.a")
  print("8.Hello world!")
  
})

